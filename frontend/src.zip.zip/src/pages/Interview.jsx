import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";
import api from "../api/api";
import Layout from "../components/Layout";
import Loading from "../components/Loading";

function Interview() {

  const navigate = useNavigate();
  const location = useLocation();

  const questions = location.state.questions;
  const sessionId = location.state.interviewId;

  const [index, setIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [evaluation, setEvaluation] = useState("");
  const [loading, setLoading] = useState(false);

  const progress =
    ((index + 1) / questions.length) * 100;

  const submitAnswer = async () => {

    if (answer.trim() === "") {
      alert("Please enter your answer.");
      return;
    }

    setLoading(true);

    try {

      const response = await api.post("/submit-answer", {
        session_id: sessionId,
        question_number: index + 1,
        question: questions[index],
        answer: answer
      });

      setEvaluation(response.data.last_feedback);

      setLoading(false);

      if (index < questions.length - 1) {

        setTimeout(() => {

          setIndex(index + 1);
          setAnswer("");
          setEvaluation("");

        }, 3000);

      } else {

        alert("Interview Completed!");

        navigate(`/report/${sessionId}`);

      }

    } catch (err) {

      console.log(err);

      setLoading(false);

      alert("Submission Failed");

    }

  };

  return (

    <Layout>
        {loading && <Loading />}

      <div className="max-w-5xl mx-auto">

        <div className="bg-white rounded-xl shadow-xl p-8">

          <h1 className="text-3xl font-bold mb-2">
            AI Technical Interview
          </h1>

          <p className="text-gray-500 mb-5">
            Question {index + 1} of {questions.length}
          </p>

          <div className="w-full bg-gray-200 rounded-full h-3 mb-8">

            <div
              className="bg-blue-600 h-3 rounded-full"
              style={{
                width: `${progress}%`
              }}
            ></div>

          </div>

          <div className="bg-blue-50 border-l-4 border-blue-600 rounded-lg p-6 mb-6">

            <h2 className="text-xl font-semibold mb-3">
              AI Interviewer
            </h2>

            <p className="text-lg">
              {questions[index]}
            </p>

          </div>

          <textarea
            rows={10}
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            placeholder="Write your answer here..."
            className="w-full border rounded-lg p-4 focus:ring-2 focus:ring-blue-500 outline-none"
          />

          <button
            onClick={submitAnswer}
            disabled={loading}
            className="mt-6 w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition"
          >
            {loading ? "AI is Evaluating..." : "Submit Answer"}
          </button>

          {evaluation && (

            <div className="mt-8 bg-green-50 border-l-4 border-green-500 rounded-lg p-5">

              <h2 className="text-xl font-bold mb-3">
                AI Feedback
              </h2>

              <pre className="whitespace-pre-wrap">
                {evaluation}
              </pre>

            </div>

          )}

        </div>

      </div>

    </Layout>

  );

}

export default Interview;